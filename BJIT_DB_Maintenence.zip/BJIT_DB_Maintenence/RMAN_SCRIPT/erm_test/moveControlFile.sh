#!/bin/bash
##Script created by Paresh K. on 07-Oct-2015 to move Control Files to /RMAN_BACKUP mount.##
#
#  The puprose of the script is to move Control Files so that all restoration files
#+ are at single location i.e. /RMAN_BACKUP for which Tieto takes a backUp everyday.
#
YEAR=`date +%Y`
MONTH=`date +%m`
DAY=`date +%d`
DATE=`date +%F`
DATE_PATTERN=$YEAR$MONTH$DAY
ORACLE_HOME=/data/app/oracle/product/12.2.0/dbhome_1;export ORACLE_HOME
SOURCE="$ORACLE_HOME/dbs";export SOURCE
DESTINATION=/RMAN_BACKUP_479B/erm_test;export DESTINATION
export LOGFILE=/home/oracle/bjit_ams/RMAN_SCRIPTS/erm_test/RMAN_SCRIPT_LOG/moveControlFile_$DATE.log
echo "Start time: `date`" > $LOGFILE
### Moving Files ###
echo "Moving following files to $DESTINATION" >> $LOGFILE
echo "" >> $LOGFILE
find $SOURCE -maxdepth 1 -type f -name "c*$DATE_PATTERN*" -exec ls '{}' \; >> $LOGFILE
find $SOURCE -maxdepth 1 -type f -name "c*$DATE_PATTERN*" -exec mv '{}' $DESTINATION \; >> $LOGFILE
echo "" >> $LOGFILE
echo "Done." >> $LOGFILE
### Sending Notification Mail ###
echo "Sending Mail..." >> $LOGFILE
SERVER=`hostname`
echo "Server = $SERVER" >> $LOGFILE
SUBJECT="Control files BackedUp on $SERVER on $DATE"
MESSAGE="The control files have been moved to $DESTINATION on $SERVER.\nThe logs are present in $LOGFILE file."
USER=Valmet_ERM_Support_BJIT@valmet.com,monirul.khan@bjitgroup.com,rahman.mostafiz@bjitgroup.com
echo -e "$MESSAGE" | mailx -s "$SUBJECT" "$USER"
echo "Done." >> $LOGFILE
echo "End time: `date`" >> $LOGFILE
