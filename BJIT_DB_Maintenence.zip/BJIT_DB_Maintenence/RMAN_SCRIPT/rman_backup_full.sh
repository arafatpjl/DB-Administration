#!/bin/bash
ORACLE_HOME=/data/app/oracle/product/12.2.0/dbhome_1;export ORACLE_HOME
ORACLE_SID=ilnk;export ORACLE_SID
ORAENV_ASK=NO;export ORAENV_ASK
LD_LIBRARY_PATH=$ORACLE_HOME/lib;export LD_LIBRARY_PATH
PATH=$ORACLE_HOME/bin:$PATH; export PATH
USER=oracle
Today="`date +%d%m%Y`" # month number, day of month, year
/data/app/oracle/product/12.2.0/dbhome_1/bin/rman target sys/sys@${ORACLE_SID} log=/home/oracle/bjit_ams/RMAN_SCRIPTS/ilnk/RMAN_SCRIPT_LOG/ILNK_RMAN_FULL_Backup_$Today.log << EOF
run{
allocate channel c1 device type disk format '/RMAN_BACKUP_479B/ilnk/ILNK_FULL_%U.bak';
allocate channel c2 device type disk format '/RMAN_BACKUP_479B/ilnk/ILNK_FULL_%U.bak';
backup incremental level 0
database filesperset 20 include current controlfile;
sql 'alter system archive log current';
backup archivelog all
skip inaccessible;
}
exit;
EOF
