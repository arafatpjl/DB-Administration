#!/bin/bash
## Script created by Monirul Islam Khan,BJIT Limited. 
## 
##+ 
##+ Move yesterdays RMAN backUp and Control files to v0479B.
##+ Remove 5 days older RMAN backUp and Control files from v0479B.
##
##The purpose of the script is to keep RMAN backUp of 2 days on local server.
##
TODAY=`date +%F`
OLD_DATE=`date -d "4 day ago" +%F`
FOLDERNAME="RMAN_BACKUP_$OLD_DATE"
DESTINATION="/RMAN_BACKUP_479B/ilnk/$FOLDERNAME";export DESTINATION
export LOGFILE=/home/oracle/bjit_ams/RMAN_SCRIPTS/ilnk/RMAN_SCRIPT_LOG/moveRMANBackup_$TODAY.log
echo "Start time: `date`" > $LOGFILE
### Update for only ERM Environment::::
if [  -d $DESTINATION ]; then
  rm -rf $DESTINATION
  echo "Deleted." >> $LOGFILE
else
  echo "Files not deleted to $DESTINATION properly." >> $LOGFILE
fi
echo "End time: `date`" >> $LOGFILE