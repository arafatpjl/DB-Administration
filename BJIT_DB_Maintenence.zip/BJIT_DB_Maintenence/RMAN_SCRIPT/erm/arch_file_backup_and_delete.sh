#!/bin/bash
ORACLE_HOME=/data/app/oracle/product/12.2.0/dbhome_1;export ORACLE_HOME
ORACLE_SID=erm;export ORACLE_SID
ORAENV_ASK=NO;export ORAENV_ASK
LD_LIBRARY_PATH=$ORACLE_HOME/lib;export LD_LIBRARY_PATH
PATH=$ORACLE_HOME/bin:$PATH; export PATH
USER=oracle
Today="`date +%d%m%Y`" # month number, day of month, year
/data/app/oracle/product/12.2.0/dbhome_1/bin/rman target sys/sys@${ORACLE_SID} log=/home/oracle/bjit_ams/RMAN_SCRIPTS/erm/RMAN_SCRIPT_LOG/ERM_RMAN_Archive_Backup_Delete_$Today.log << EOF
run{
allocate channel c1 device type disk format '/data/RMAN_BACKUP/ERM_ARC_%U.bak';
allocate channel c2 device type disk format '/data/RMAN_BACKUP/ERM_ARC_%U.bak';
sql 'alter system archive log current';
backup archivelog until time 'sysdate-2' delete input
skip inaccessible;
}
exit;
EOF
