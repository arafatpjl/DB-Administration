#!/bin/bash
## Script created by Monirul Islam Khan,BJIT Limited. 
## 
##+ 
##+ Move yesterdays RMAN backUp and Control files to v0479B.
##+ Remove 5 days older RMAN backUp and Control files from v0479B.
##
##The purpose of the script is to keep RMAN backUp of 2 days on local server.
##
TODAY=`date +%F`
OLD_DATE=`date -d "2 days ago" +%F`
FOLDERNAME="RMAN_BACKUP_$TODAY"
SOURCE="/data/RMAN_BACKUP/$FOLDERNAME";export SOURCE
DESTINATION="/RMAN_BACKUP_479B/erm/$FOLDERNAME";export DESTINATION
export LOGFILE=/home/oracle/bjit_ams/RMAN_SCRIPTS/erm/RMAN_SCRIPT_LOG/moveRMANBackup_$TODAY.log
echo "Start time: `date`" > $LOGFILE
### Update for only ERM Environment::::
if [  $SOURCE ]; then
  cp -R $SOURCE $DESTINATION
  echo "Copied." >> $LOGFILE
else
  echo "Files not Copied to $DESTINATION properly." >> $LOGFILE
fi
echo "End time: `date`" >> $LOGFILE


####TODAY=`date +%F`
#OLD_DATE=`date -d "4 days ago" +%F`
#FOLDERNAME1="RMAN_BACKUP_$OLD_DATE"
#SOURCE1="/RMAN_BACKUP_479B/prod/$FOLDERNAME";export SOURCE1
#export LOGFILE=/home/oracle/bjit_ams/RMAN_SCRIPTS/RMAN_SCRIPT_LOG/moveRMANBackup_$TODAY.log
#echo "Start time: `date`" > $LOGFILE
#### Update for only ERM Environment::::
#if [  -d $SOURCE1 ]; then
#  rm -rf $SOURCE1
#  echo "Removed." >> $LOGFILE
#else
#  echo "Files not removed from SOURCE1" >> $LOGFILE
#fi
#echo "End time: `date`" >> $LOGFILE