#!/bin/bash
#
# Simple script wrapper to restore PDMPROD2 production database
# dump to the secondary server via RMAN.
#
# Pre-requisite: Oracle instance has been created but is currently
#                shutdown. The secondary server instance should always
#                be in shutdown mode unless actually being taken into
#                use or under recovery exercise.
#
# 2016-06-06 Henri Virtanen, modified version based on the BJIT script
#
# Usage: ./rman_restore.sh

ARCHIVELOG_LOCATION="/data/archive"
TEMP_TABLESPACE_DATAFILE_LOCATION="/data/app/oracle/oradata/erm"

# Static configuration values based on PDM production instance
DBID="405529491"

# Set Oracle Environment Variable
ORACLE_SID="erm"
ORACLE_HOME="/data/app/oracle/product/12.2.0/dbhome_1"
LD_LIBRARY_PATH="$ORACLE_HOME/lib"
PATH="$ORACLE_HOME/bin:$PATH"
export ORACLE_SID PATH LD_LIBRARY_PATH ORACLE_HOME

# Runtime variables
LOGDIR="`dirname $0`/log"
CF_FOUND=0

# Ask which backup location to use
BASE_RESTORE_FROM="/data/RMAN_BACKUP"

echo "Please select the backup you want to restore."
echo

PS3='Please enter your choice: '
options=($BASE_RESTORE_FROM/RMAN*)

select opt in "${options[@]}"
do
    case $opt in
        *)  RESTORE_FROM=$opt
            break
            ;;
    esac
done
echo

# Fetch the control file from the restore location
for cf in $RESTORE_FROM/c*;do
    #echo "Found controlfile backup from: $cf"
    CF_FOUND=1
    CFILE=$cf
done

# Check that we found a backup controlfile
if [ $CF_FOUND -eq 1 ]; then
    echo "Using controlfile $CFILE"
else
    echo "Cannot find controlfile backup from $RESTORE_FROM"
    exit
fi

# Stop if the instance is currently running
SMON_PID=`pgrep -f smon_$ORACLE_SID`
if [ "$?" == 0 ]; then
    echo "Instance $ORACLE_SID is running, please shutdown it before restoration!"
    exit
fi

# Start fixing the catalog and listing valid backups
echo "Starting RMAN restore on `date +"%D-%H:%M:%S"`"
echo
echo "Syncing catalog content from $RESTORE_FROM, please wait..."

LOGFILE="$LOGDIR/rman_catalog_crosscheck-`date +"%Y%m%d-%H%M%S"`.log"
touch $LOGFILE
rman target sys/sys > /dev/null <<EOF
SPOOL LOG to '$LOGFILE';
SET DBID=$DBID;
STARTUP NOMOUNT;
RUN {
   allocate channel c1 device type disk format '/data/RMAN_BACKUP/ERM_ARC_%U.bak';
   allocate channel c2 device type disk format '/data/RMAN_BACKUP/ERM_ARC_%U.bak';
  # Restore control file from the backupset
  RESTORE CONTROLFILE FROM '$CFILE';
  # Mount the database
  ALTER DATABASE MOUNT;
  # Catalog the backup location
  CATALOG START WITH '$RESTORE_FROM' NOPROMPT;
  # Catalog the archive logs present on disk/copied from master
  CATALOG START WITH '$ARCHIVELOG_LOCATION' NOPROMPT;
  # Crosscheck the backups
  CROSSCHECK ARCHIVELOG ALL;
  CROSSCHECK BACKUP;
  CROSSCHECK BACKUP OF ARCHIVELOG ALL SPFILE;
  # Delete expired and unavailable backups from the catalog
  DELETE NOPROMPT EXPIRED BACKUP;
  DELETE NOPROMPT EXPIRED ARCHIVELOG ALL;
  DELETE NOPROMPT EXPIRED BACKUP OF CONTROLFILE;
}
LIST BACKUP;
LIST BACKUP SUMMARY;
SPOOL LOG OFF;
EOF

#list backup of database summary completed after 'sysdate - 1';
LOGFILE="$LOGDIR/rman_restore-`date +"%Y%m%d-%H%M%S"`.log"
touch $LOGFILE

# Show list of archivelog for SCN choices
rman target sys/sys > /dev/null <<EOF
SPOOL LOG to '$LOGFILE';
LIST BACKUP;
SPOOL LOG OFF;
EOF
cat $LOGFILE
rm -f $LOGFILE 2> /dev/null

scnname=""
echo -n "Please enter the SCN which to restore (HINT: select the highest 'Next SCN' column): "
read scnname

LOGFILE="$LOGDIR/rman_restore-`date +"%Y%m%d-%H%M%S"`.log"
echo
echo "Logfile $LOGFILE can be followed for details"
echo -n "Starting restore to SCN $scnname. This may take a while... "

touch $LOGFILE
rman target sys/sys > /dev/null <<EOF
SPOOL LOG to '$LOGFILE';
RUN {
  allocate channel c1 device type disk format '/data/RMAN_BACKUP/ERM_ARC_%U.bak';
  allocate channel c2 device type disk format '/data/RMAN_BACKUP/ERM_ARC_%U.bak';
  SET UNTIL SCN $scnname;
  RESTORE DATABASE;
  RECOVER DATABASE;
  ALTER DATABASE OPEN RESETLOGS;
}
SPOOL LOG OFF;
EOF
echo "OK"

LOGFILE="$LOGDIR/rman_create_tablespaces-`date +"%Y%m%d-%H%M%S"`.log"
touch $LOGFILE
echo
echo -n "Recreating the TEMP tablespace datafiles... "
rm -f $TEMP_TABLESPACE_DATAFILE_LOCATION/temp*.dbf
sqlplus 'sys/sys as sysdba' > /dev/null <<EOF
spool $LOGFILE
alter tablespace temp drop tempfile '$TEMP_TABLESPACE_DATAFILE_LOCATION/temp01.dbf';
alter tablespace temp drop tempfile '$TEMP_TABLESPACE_DATAFILE_LOCATION/temp02.dbf';
alter tablespace temp drop tempfile '$TEMP_TABLESPACE_DATAFILE_LOCATION/temp03.dbf';
alter tablespace temp drop tempfile '$TEMP_TABLESPACE_DATAFILE_LOCATION/temp04.dbf';
alter tablespace temp drop tempfile '$TEMP_TABLESPACE_DATAFILE_LOCATION/temp05.dbf';
alter tablespace temp drop tempfile '$TEMP_TABLESPACE_DATAFILE_LOCATION/temp06.dbf';
alter tablespace temp drop tempfile '$TEMP_TABLESPACE_DATAFILE_LOCATION/temp07.dbf';
alter TABLESPACE  TEMP add tempfile '$TEMP_TABLESPACE_DATAFILE_LOCATION/temp01.dbf' SIZE 5M AUTOEXTEND ON MAXSIZE UNLIMITED;
alter TABLESPACE  TEMP add tempfile '$TEMP_TABLESPACE_DATAFILE_LOCATION/temp02.dbf' SIZE 5M AUTOEXTEND ON MAXSIZE UNLIMITED;
alter TABLESPACE  TEMP add tempfile '$TEMP_TABLESPACE_DATAFILE_LOCATION/temp03.dbf' SIZE 5M AUTOEXTEND ON MAXSIZE UNLIMITED;
alter TABLESPACE  TEMP add tempfile '$TEMP_TABLESPACE_DATAFILE_LOCATION/temp04.dbf' SIZE 5M AUTOEXTEND ON MAXSIZE UNLIMITED;
alter TABLESPACE  TEMP add tempfile '$TEMP_TABLESPACE_DATAFILE_LOCATION/temp05.dbf' SIZE 5M AUTOEXTEND ON MAXSIZE UNLIMITED;
alter TABLESPACE  TEMP add tempfile '$TEMP_TABLESPACE_DATAFILE_LOCATION/temp06.dbf' SIZE 5M AUTOEXTEND ON MAXSIZE UNLIMITED;
alter TABLESPACE  TEMP add tempfile '$TEMP_TABLESPACE_DATAFILE_LOCATION/temp07.dbf' SIZE 5M AUTOEXTEND ON MAXSIZE UNLIMITED;
select name,open_mode from v\$database;
exit;
EOF
echo "OK"

echo
echo "Restoration done! Please review logfiles from $LOGDIR"
exit 0
