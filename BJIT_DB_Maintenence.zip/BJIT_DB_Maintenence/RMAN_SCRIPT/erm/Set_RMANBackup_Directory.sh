#!/bin/bash
# Script created by Monirul Islam Khan, BJIT Limited to
# If files count is not correct then move to error folder and send mail.
#+ set and oraganise the /data/RMAN_BACKUP directory files.
#
#  The puprose of the script is to create a directory within /data/RMAN_BACKUP mount as a preqrequisite for 
#+ Clean_And_Move_RMANBackup_files.sh script.
#
TODAY=`date +%F`
FOLDERNAME="RMAN_BACKUP_$TODAY"
SOURCE="/data/RMAN_BACKUP";export SOURCE
USER=Valmet_ERM_Support_BJIT@valmet.com,monirul.khan@bjitgroup.com,rahman.mostafiz@bjitgroup.com
export LOGFILE=/home/oracle/bjit_ams/RMAN_SCRIPTS/erm/RMAN_SCRIPT_LOG/setRMANBackupDirectory_$TODAY.log
BackupFileCount=`find /data/RMAN_BACKUP/ -maxdepth 1 -name "*.bak" -type f | wc -l`
ControlFileCount=`find /data/RMAN_BACKUP/ -maxdepth 1 -name "c*" -type f | wc -l`
echo "Start Time: `date`" > $LOGFILE
echo "Number of BackUp files is/are $BackupFileCount" >> $LOGFILE
echo "Number of Control files is/are $ControlFileCount" >> $LOGFILE
FOLDERNAME="RMAN_BACKUP_$TODAY"
DESTINATION="$SOURCE/$FOLDERNAME";export DESTINATION
cd $SOURCE
echo "In directory `pwd`" >> $LOGFILE
if [ ! -d $FOLDERNAME ]; then
	echo "Creating Directory $FOLDERNAME" >> $LOGFILE
	mkdir $FOLDERNAME
fi
echo "Moving following files..." >> $LOGFILE
find $SOURCE -maxdepth 1 -name "*.bak" -type f -exec ls '{}' \; >> $LOGFILE
find $SOURCE -maxdepth 1 -name "c*" -type f -exec ls '{}' \; >> $LOGFILE
find $SOURCE -maxdepth 1 -name "*.bak" -type f -exec mv '{}' "$DESTINATION" \; >> $LOGFILE
find $SOURCE -maxdepth 1 -name "c*" -type f -exec mv '{}' "$DESTINATION" \; >> $LOGFILE
echo "Moved." >> $LOGFILE
echo "End Time: `date`" >> $LOGFILE
