#!/bin/bash
## user : sys as sysdba
## pass : sys
## Start DB Datapump Backup DBA Tasks:
###nohup sh oracle_common_db_expdp_backup_for_linux.sh ERMTEST sys ERM_DATA_PUMP /data/data_PUMP /data/app/oracle/product/12.2.0/dbhome_1 /home/oracle/bjit_ams/scripts >> /home/oracle/bjit_ams/scripts/Logs/oracle_common_db_expdp_backup_for_linux.log &2
##db_common_expdp_for_linux.sh>>Script Name
##ERMTEST=DB_SID>>DB Sid name
##sys=SYS_PASS>>Admin user password
##ERM_DATA_PUMP=DB_Directory>>Directory name
##/data/data_PUMP=DB_Directory_loc>>Directory Location, where dump file will be reside
##/data/app/oracle/product/12.2.0/dbhome_1=ORACLE_HOME>>Oracle home location
##/home/oracle/bjit_ams/scripts=SCRIPTS_LOCATION>>location of shell script
TIMESTAMP=`date +"%D-%H:%M:%S"`
echo "Start DB Datapump Backup DateTime ::"$TIMESTAMP
TIMESTAMP=`date +"%D-%H:%M:%S"`
DB_SID=$1
SYS_PASS=$2
DB_Directory=$3
DB_Directory_loc=$4
ORACLE_HOME=$5
SCRIPTS_LOCATION=$6
export ORACLE_SID=$DB_SID
export ORACLE_HOME=$ORACLE_HOME
DATE=`date "+%Y-%m-%d"`
MailToList="monirul.khan@bjitgroup.com,iqbal.hossen@bjitgroup.com,rahman.mostafiz@bjitgroup.com,Valmet_PDM_Support_BJIT@valmet.com";
MAIL_ATTACH_FILE="$SCRIPTS_LOCATION/Logs/oracle_common_db_expdp_backup_for_linux.log"
HOST=`hostname`
MAIL_SUBJECT=$DB_SID"_Datapump_Backup_Status_For_"$HOST
MAIL_FROM=$DB_SID"_DB_Maintenence@valmet.com"
echo -e "Start Datapump Backup DateTime ::$TIMESTAMP\n"| mailx -r $MAIL_FROM -a $MAIL_ATTACH_FILE -s $MAIL_SUBJECT -S smtp="smtp.valmet.com:25" $MailToList;
#### Create Dump Directory.
TIMESTAMP=`date +"%D-%H:%M:%S"`
echo -e "Start Create Dump Directory DateTime ::$TIMESTAMP\n" | mailx -r $MAIL_FROM -a $MAIL_ATTACH_FILE -s $MAIL_SUBJECT -S smtp="smtp.valmet.com:25" $MailToList;
echo "Start Create Dump Directory DateTime ::"$TIMESTAMP
sqlplus SYS/$SYS_PASS@$DB_SID as sysdba <<EOF
CREATE OR REPLACE DIRECTORY $DB_Directory as '$DB_Directory_loc';
GRANT READ, WRITE ON DIRECTORY $DB_Directory to SYSTEM;
GRANT EXP_FULL_DATABASE TO SYSTEM;
exit;
EOF
TIMESTAMP=`date +"%D-%H:%M:%S"`
echo -e "Start Create Dump Directory DateTime ::$TIMESTAMP\n" | mailx -r $MAIL_FROM -a $MAIL_ATTACH_FILE -s $MAIL_SUBJECT -S smtp="smtp.valmet.com:25" $MailToList;
export ORACLE_SID=$DB_SID
export ORACLE_HOME=$ORACLE_HOME
#### Export Database with DATAPUMP Utility.
TIMESTAMP=`date +"%D-%H:%M:%S"`
echo -e "Start Export Database with DATAPUMP Utility DateTime ::$TIMESTAMP\n" | mailx -r $MAIL_FROM -a $MAIL_ATTACH_FILE -s $MAIL_SUBJECT -S smtp="smtp.valmet.com:25" $MailToList;
echo "Start Export Database with DATAPUMP Utility DateTime ::"$TIMESTAMP
Filename=$DB_SID"_EXPDP_Dump_"`date +%Y-%m-%d`
DumpFile=${Filename}".DMP"
LogFile=${Filename}".log" 
SCHEMA=$(sqlplus -s SYS/$SYS_PASS as sysdba  << EOF
set pagesize 0 feedback off verify off heading off echo off;
SELECT RTRIM(
  (XMLAGG(XMLELEMENT(E,USERNAME||',') ORDER BY USERNAME ).EXTRACT('//text()')).GETCLOBVAL(),
    ',') USERNAME
FROM DBA_USERS 
WHERE ACCOUNT_STATUS='OPEN'
AND USERNAME NOT IN ('SYS','SYSTEM','DMSYS','EXFSYS','MDSYS','OLAPSYS','OJVMSYS','ORDSYS','SYSBACKUP','SYSDG','SYSKM','TSMSYS','SYSMAN','WMSYS','APPQOSSYS','AUDSYS','CTXSYS','RMAN','ZABBIX')
ORDER BY 1;
exit;
EOF
)
expdp \'SYS/$SYS_PASS@$DB_SID as sysdba\' directory=$DB_Directory DUMPFILE=${DumpFile} schemas=$SCHEMA LOGFILE=${LogFile};
TIMESTAMP=`date +"%D-%H:%M:%S"`
echo -e "End Export Database with Export Utility DateTime ::$TIMESTAMP\n" | mailx -r $MAIL_FROM -a $MAIL_ATTACH_FILE -s $MAIL_SUBJECT -S smtp="smtp.valmet.com:25" $MailToList;
echo "End Export Database with DATAPUMP Utility DateTime ::"$TIMESTAMP
TIMESTAMP=`date +"%D-%H:%M:%S"`
echo "End DB Datapump Backup DateTime ::"$TIMESTAMP
exit;
