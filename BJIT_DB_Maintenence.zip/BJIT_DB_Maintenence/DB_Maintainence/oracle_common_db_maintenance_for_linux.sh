#!/bin/bash
## user : sys as sysdba
## pass : sys
##go to Script location for run the scripts
##MailToList should be changed according to project
## Start DB Maintainenence DBA Tasks:
###nohup sh db_common_maintenance.sh CATIADB SCOTT sys CATIA_DATA_PUMP /u01/app/oracle/admin/catiadb/dpdump/ /u01/app/oracle/product/12.1.0/dbhome_1 /home/oracle/test  >> /home/oracle/test/logs/db_maintainence_dba_tasks.log &2

TIMESTAMP=`date +"%D-%H:%M:%S"`
echo "Start DB Maintainenence DateTime ::"$TIMESTAMP
TIMESTAMP=`date +"%D-%H:%M:%S"`
DB_SID=$1
SCHEMA_NAME=$2
SYS_PASS=$3
DB_Directory=$4
DB_Directory_loc=$5
ORACLE_HOME=$6
SCRIPTS_LOCATION=$7
export ORACLE_SID=$DB_SID
export ORACLE_HOME=$ORACLE_HOME
DATE=`date "+%Y-%m-%d"`
MailToList="monirul.khan@bjitgroup.com arafat.hossan@bjitgroup.com ";
MAIL_ATTACH_FILE="$SCRIPTS_LOCATION/logs/db_maintainence_dba_tasks.log"
HOST=`hostname`
MAIL_SUBJECT=$DB_SID"_DB_Maintenence_Status_For_"$HOST
MAIL_FROM=$DB_SID"_DB_Maintenence@valmet.com"
echo -e "Start DB Maintainenence DateTime ::$TIMESTAMP\n"| mailx -r $MAIL_FROM -a $MAIL_ATTACH_FILE -s $MAIL_SUBJECT -S smtp="smtp.valmet.com:25" $MailToList;
DB_VER=$(sqlplus SYS/$SYS_PASS as sysdba <<EOF
set pagesize 0 feedback off verify off heading off echo off;
SELECT substr(version,1,2) FROM v$instance;
exit;
EOF
)
#### Create Dump Directory.
TIMESTAMP=`date +"%D-%H:%M:%S"`
##echo -e "Start Create Dump Directory DateTime ::$TIMESTAMP\n" | mailx -r $MAIL_FROM -a $MAIL_ATTACH_FILE -s $MAIL_SUBJECT -S smtp="smtp.valmet.com:25" $MailToList;
echo "Start Create Dump Directory DateTime ::"$TIMESTAMP
sqlplus SYS/$SYS_PASS@$DB_SID as sysdba <<EOF
CREATE OR REPLACE DIRECTORY $DB_Directory as '$DB_Directory_loc';
GRANT READ, WRITE ON DIRECTORY $DB_Directory to SYSTEM;
exit;
EOF
TIMESTAMP=`date +"%D-%H:%M:%S"`
echo -e "Start Create Dump Directory DateTime ::$TIMESTAMP\n" | mailx -r $MAIL_FROM -a $MAIL_ATTACH_FILE -s $MAIL_SUBJECT -S smtp="smtp.valmet.com:25" $MailToList;
export ORACLE_SID=$DB_SID
export ORACLE_HOME=$ORACLE_HOME
#### Export Database with Export Utility.
TIMESTAMP=`date +"%D-%H:%M:%S"`
echo -e "Start Export Database with Export Utility DateTime ::$TIMESTAMP\n" | mailx -r $MAIL_FROM -a $MAIL_ATTACH_FILE -s $MAIL_SUBJECT -S smtp="smtp.valmet.com:25" $MailToList;
echo "Start Export Database with Export Utility DateTime ::"$TIMESTAMP
Filename=$DB_SID"_EXP_Dump_"`date +%Y-%m-%d`
DumpFile=${Filename}".DMP"
LogFile=${Filename}".log" 
SCHEMA=$(sqlplus -s SYS/$SYS_PASS as sysdba  << EOF
set pagesize 0 feedback off verify off heading off echo off;
select rtrim((Xmlagg(Xmlelement(e,concat(USERNAME,',')) ORDER BY USERNAME ).extract('//text()')).getclobval(),',') USERNAME  
from dba_users 
where account_status='OPEN' and username NOT LIKE 'SYS%' order by 1;  
exit;
EOF
)
expdp \'SYS/$SYS_PASS as sysdba\' directory=$DB_Directory DUMPFILE=${DumpFile} schemas=$SCHEMA LOGFILE=${LogFile};
TIMESTAMP=`date +"%D-%H:%M:%S"`
echo -e "End Export Database with Export Utility DateTime ::$TIMESTAMP\n" | mailx -r $MAIL_FROM -a $MAIL_ATTACH_FILE -s $MAIL_SUBJECT -S smtp="smtp.valmet.com:25" $MailToList;
echo "End Export Database with Export Utility DateTime ::"$TIMESTAMP
#### Check DB & Prepare for DBA activities & put DB in non archive mode
#### This will start gathering statistics
TIMESTAMP=`date +"%D-%H:%M:%S"`
echo -e "Start Check DB , Prepare for DBA activities , put DB in non archive mode DateTime ::$TIMESTAMP\n" | mailx -r $MAIL_FROM -a $MAIL_ATTACH_FILE -s $MAIL_SUBJECT -S smtp="smtp.valmet.com:25" $MailToList;
echo "Start Check DB , Prepare for DBA activities , put DB in non archive mode DateTime ::"$TIMESTAMP
TMPTBS=$(sqlplus -s SYS/$SYS_PASS as sysdba  << EOF
set pagesize 0 space 0 linesize 100 feedback off verify off heading off echo off;
spool $SCRIPTS_LOCATION/tmptbs_${DB_SID}_150.sql
select 'ALTER DATABASE' ||' TEMPFILE ' ||''''|| NAME ||'''' ||' RESIZE '||TO_CHAR(BYTES+536870912)||';' FROM V\$TEMPFILE;
spool off;
exit;
EOF
)
###fucntion for check gather_statistics
gather_stats () {
 if [[ "${DB_VER}" == "10" ]];then
sqlplus SYS/$SYS_PASS@$DB_SID as sysdba <<EOF
select name from V\$database;
execute DBMS_SCHEDULER.DISABLE('GATHER_STATS_JOB') ;
execute sys.dbms_stats.drop_stat_table(ownname=>'$SCHEMA_NAME',stattab=>'${SCHEMA_NAME}_STATS');
execute sys.dbms_stats.create_stat_table(ownname=>'$SCHEMA_NAME',stattab=>'${SCHEMA_NAME}_STATS');
execute sys.dbms_stats.export_schema_stats(ownname=>'$SCHEMA_NAME',stattab=>'${SCHEMA_NAME}_STATS');
execute sys.dbms_stats.gather_dictionary_stats( cascade=>TRUE, estimate_percent=>100, options=>'GATHER');
execute sys.dbms_stats.gather_fixed_objects_stats;
execute sys.dbms_stats.gather_system_stats('Start');
exit;
EOF
  else
sqlplus SYS/$SYS_PASS@$DB_SID as sysdba <<EOF
select name from V\$database;
execute dbms_auto_task_admin.disable(client_name => 'auto optimizer stats collection',operation => NULL,window_name => NULL);
execute sys.dbms_stats.drop_stat_table(ownname=>'SYS',stattab=>'${SCHEMA_NAME}_STATS');
execute sys.dbms_stats.create_stat_table(ownname=>'SYS',stattab=>'${SCHEMA_NAME}_STATS');
grant all on ${SCHEMA_NAME}_STATS TO ${SCHEMA_NAME};
execute sys.dbms_stats.gather_table_stats (ownname =>'${SCHEMA_NAME}',tabname =>'${SCHEMA_NAME}_STATS');
execute sys.dbms_stats.export_schema_stats(ownname=>'$SCHEMA_NAME',stattab=>'${SCHEMA_NAME}_STATS',statown=>'SYS');
execute sys.dbms_stats.gather_dictionary_stats( cascade=>TRUE, estimate_percent=>100, options=>'GATHER');
execute sys.dbms_stats.gather_fixed_objects_stats;
execute sys.dbms_stats.gather_system_stats('Start');
exit;
EOF
 fi 
 }
sqlplus SYS/$SYS_PASS@$DB_SID as sysdba <<EOF
select name from V\$database;
@$SCRIPTS_LOCATION/tmptbs_${DB_SID}_150.sql
shutdown immediate; 
startup mount ;
alter database noarchivelog;
alter database open;
exit;
EOF
gather_stats
TIMESTAMP=`date +"%D-%H:%M:%S"`
echo -e "End Check DB , Prepare for DBA activities , put DB in non archive mode DateTime ::$TIMESTAMP\n" | mailx -r $MAIL_FROM -a $MAIL_ATTACH_FILE -s $MAIL_SUBJECT -S smtp="smtp.valmet.com:25" $MailToList;
echo "End Check DB , Prepare for DBA activities , put DB in non archive mode DateTime ::"$TIMESTAMP
#### Statistic collection

TIMESTAMP=`date +"%D-%H:%M:%S"`
echo -e "Start Statistic collection DateTime ::$TIMESTAMP\n" | mailx -r $MAIL_FROM -a $MAIL_ATTACH_FILE -s $MAIL_SUBJECT -S smtp="smtp.valmet.com:25" $MailToList;
echo "Start Statistic collection DateTime ::"$TIMESTAMP
sqlplus SYS/$SYS_PASS@$DB_SID as sysdba <<EOF
execute sys.dbms_stats.gather_schema_stats( ownname=>'$SCHEMA_NAME',cascade=>FALSE,degree=>dbms_stats.default_degree,estimate_percent=>100);
select trunc(last_analyzed) analysed, count(*) tables from dba_tables where owner = '$SCHEMA_NAME' group by trunc(last_analyzed) order by 1;
execute sys.dbms_stats.gather_system_stats('Stop'); 
exit;
EOF
TIMESTAMP=`date +"%D-%H:%M:%S"`
echo -e "End Statistic collection DateTime ::$TIMESTAMP\n" | mailx -r $MAIL_FROM -a $MAIL_ATTACH_FILE -s $MAIL_SUBJECT -S smtp="smtp.valmet.com:25" $MailToList;
echo "End Statistic collection DateTime ::"$TIMESTAMP
#### Rebuild index
TIMESTAMP=`date +"%D-%H:%M:%S"`
echo -e "Start Rebuild index DateTime ::$TIMESTAMP\n" | mailx -r $MAIL_FROM -a $MAIL_ATTACH_FILE -s $MAIL_SUBJECT -S smtp="smtp.valmet.com:25" $MailToList;
echo "Start Rebuild index DateTime ::"$TIMESTAMP
####### Problem when this folowing scripts run so BJIT took rebuiltindex.sql in EOF 
sqlplus -s SYS/$SYS_PASS@$DB_SID as sysdba <<EOF
set heading off verify off feedback off echo off term off pagesize 0 linesize 10000 trimspool on timing off pages 0 TERMOUT OFF ;
spool $SCRIPTS_LOCATION/rebuildindx_$DB_SID.sql
SELECT 'ALTER INDEX' ||' '|| Owner ||'.'|| INDEX_NAME || ' rebuild tablespace '||TABLESPACE_NAME ||
' compute statistics parallel; '
AS INDEXNAME FROM dba_indexes
where index_type = 'NORMAL'
and owner in( select USERNAME  
from dba_users 
where account_status='OPEN' and username NOT LIKE 'SYS%')
and TABLESPACE_NAME is not null order by owner;
spool off;
exit;
EOF
####FOR quick search used in PDM###
FTS=$(sqlplus -s SYS/$SYS_PASS@$DB_SID as sysdba <<EOF
set pagesize 0 linesize 100 feedback off verify off heading off echo off;
select count(USERNAME) AS USERNAME
from dba_users 
where account_status='OPEN' and username NOT LIKE 'SYS%'
and username='ERM13_ACAT';
exit;
EOF
)
if [[ "${FTS}" -eq "1" ]];then
sed -i '$ a begin' rebuildindx_${DB_SID}.sql
sed -i '$ a end;' rebuildindx_${DB_SID}.sql
sed -i '$ a /'rebuildindx_${DB_SID}.sql 
fi
sqlplus -s SYS/$SYS_PASS@$DB_SID as sysdba <<EOF
@$SCRIPTS_LOCATION/rebuildindx_${DB_SID}.sql;
select trunc(last_analyzed) analysed, count(*) indexes from dba_indexes where owner = '$SCHEMA_NAME' group by trunc(last_analyzed) order by 1;
select * from recyclebin;
purge recyclebin; 
set pagesize 0 linesize 100 feedback off verify off heading off echo off;
spool $SCRIPTS_LOCATION/tmptbs_${DB_SID}_30.sql
select 'ALTER DATABASE' ||' TEMPFILE ' ||''''|| NAME ||'''' ||' RESIZE '||TO_CHAR(BYTES- 536870912)||';' FROM V\$TEMPFILE;
spool off;
@$SCRIPTS_LOCATION/tmptbs_${DB_SID}_30.sql;
shutdown immediate;
startup mount ;
alter database archivelog;
alter database open;
archive log list;
exit;
EOF
TIMESTAMP=`date +"%D-%H:%M:%S"`
echo "remove all created spool files"
rm -f $SCRIPTS_LOCATION/tmptbs_${DB_SID}_150.sql
rm -f $SCRIPTS_LOCATION/tmptbs_${DB_SID}_30.sql
rm -f $SCRIPTS_LOCATION/rebuildindx_$DB_SID.sql
echo -e "End Rebuild index DateTime ::$TIMESTAMP\n" | mailx -r $MAIL_FROM -a $MAIL_ATTACH_FILE -s $MAIL_SUBJECT -S smtp="smtp.valmet.com:25" $MailToList;
echo "End Rebuild index DateTime ::"$TIMESTAMP
echo -e "End DB Maintainenence DateTime ::$TIMESTAMP\n" | mailx -r $MAIL_FROM -a $MAIL_ATTACH_FILE -s $MAIL_SUBJECT -S smtp="smtp.valmet.com:25" $MailToList;
echo "End DB Maintainenence DateTime ::"$TIMESTAMP
exit;
